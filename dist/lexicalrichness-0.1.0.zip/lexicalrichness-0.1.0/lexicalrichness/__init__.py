# -*- coding: utf-8 -*-

"""Top-level package for LexicalRichness."""

__author__ = """Shen Yan Shun (Lucas)"""
__email__ = 'shen1ys@gmail.com'
__version__ = '0.1.0'
