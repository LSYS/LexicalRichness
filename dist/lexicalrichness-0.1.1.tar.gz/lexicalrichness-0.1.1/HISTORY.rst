=======
History
=======

0.1.0 (2018-05-09)
------------------

* First release on PyPI.

0.1.1 (2018-05-09)
------------------

* Changed lexicalrichness filename to LexicalRichness
