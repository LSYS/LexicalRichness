=======
History
=======

0.1.2 (2018-05-09)
------------------

* First release on PyPI.


