=======
History
=======

0.1.2 (2018-05-09)
------------------

* First release on PyPI.

0.1.3 (2018-05-27)
------------------

* Minor fix for compatibility issue with hyphens (ascii) in python 2.
