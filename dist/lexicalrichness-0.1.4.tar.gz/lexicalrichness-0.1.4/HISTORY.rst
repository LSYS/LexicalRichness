=======
History
=======

0.1.2 (2018-05-09)
------------------

* First release on PyPI.

0.1.3 (2018-05-27)
------------------

* Minor fix for compatibility issue with hyphens (ascii) in python 2.

0.1.4 (2021-11-13)
------------------
* Add textblob in setup.py as requirements (to fix "ModuleNotFoundError: No module named 'textblob'") [Christophe Bedetti].
* Make preprocessing and tokenization optional [David Lesieur].