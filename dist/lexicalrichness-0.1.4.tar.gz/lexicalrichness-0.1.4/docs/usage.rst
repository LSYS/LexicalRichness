=====
Usage
=====

To use LexicalRichness in a project::

    import lexicalrichness
